package Characters;

public class Queen extends Character{

    public Queen(String name) {
        super(name);
    }
}
