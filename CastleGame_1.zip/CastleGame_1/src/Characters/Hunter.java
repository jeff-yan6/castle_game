package Characters;

public class Hunter extends Character{
    public Hunter(String name) {
        super(name);
    }
}
