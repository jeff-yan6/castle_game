package Characters;

import java.util.HashMap;

public class Character {
    private String name;
    private String description;
    private HashMap<String, String> relation = new HashMap<String, String>();

    public Character(String name){
        this.name = name;
        // this.decription = 从文件中导入
    }
    public void say_story(){
        System.out.println(description);
    }
    public void say_something(){

    }
}
