package Characters;

import Buildings.Building;

public class Hero {
    private String name = new String();
    private Building position;
    private String items = new String();
}
