package Characters;

public class Princess extends Character {

    public Princess(String name) {
        super(name);
    }
}
