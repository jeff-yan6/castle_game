package Characters;

public class Barkeeper extends Character{
    public Barkeeper(String name){
        super(name);
    }
}
