package Buildings;

import Characters.Barkeeper;

public class Bar extends Building{
    private Barkeeper npc = new Barkeeper("jeff");

    public Bar(String Building_name) {
        super(Building_name);
    }

    public void obtain_wine(){

    }


}
