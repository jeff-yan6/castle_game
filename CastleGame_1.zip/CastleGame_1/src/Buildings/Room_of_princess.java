package Buildings;

public class Room_of_princess extends Building{

    public Room_of_princess(String Building_name) {
        super(Building_name);
    }
}
