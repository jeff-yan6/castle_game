package Buildings;

public class Room_of_queen extends Building{
    public Room_of_queen(String Building_name) {
        super(Building_name);
    }
}
