package Buildings;

public class Castle extends Building{
    public Castle(String Building_name) {
        super(Building_name);
    }
}
