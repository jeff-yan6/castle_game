package Buildings;

import java.util.HashSet;
import java.util.HashMap;

public class Building {
    private HashMap<String, Boolean> gates = new HashMap<String, Boolean>();
    private HashSet<String> people = new HashSet<String>();
    private HashSet<String> items = new HashSet<String>();
    private String Building_name;

    public Building(String Building_name){
        this.Building_name = Building_name;

        gates.put("north_gate", false);
        gates.put("south_gate", false);
        gates.put("east_gate", false);
        gates.put("west_gate", false);

    }
    public void set_north_gate(){
        gates.put("north_gate", true);
    }
    public void set_south_gate(){
        gates.put("south_gate", true);
    }
    public void set_west_gate(){
        gates.put("east_gate", true);
    }
    public void set_east_gate(){
        gates.put("west_gate", true);
    }
    public void show_Prompt(){
        System.out.println("\n----------------------");
        System.out.println("现在你在：" + Building_name);
        System.out.println("There are: ");
        for (String key : gates.keySet()) {
            if (gates.get(key)) {
                System.out.print(key + " ");
            }
        }
        System.out.println("\n----------------------");
    }
    public Building enter_building(Building building){
        return building;
    }

}
