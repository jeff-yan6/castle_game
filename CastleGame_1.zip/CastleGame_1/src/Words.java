import java.util.ArrayList;
public class Words {
    private ArrayList<String> words = new ArrayList<String>();

    public void add_word(String word){
        words.add(word);
    }

    public String output_word(){
        return "";
    }
}
