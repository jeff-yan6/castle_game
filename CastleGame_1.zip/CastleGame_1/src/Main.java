import Buildings.Building;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Building castle = new Building("城堡");
        castle.set_south_gate();
        Building pub = new Building("酒馆");
        pub.set_north_gate();
        Building forest = new Building("森林");

        Scanner input = new Scanner(System.in);
        Building now = castle;
        String instruct;
        String[] order = new String[2];
                Quit:
        while (true) {
            now.show_Prompt();
            System.out.print("请问你要做什么(输入help打开帮助): ");
            while (true) {
                instruct = input.nextLine();
                if (instruct.equals("quit")) {
                    break Quit;
                }
                if (instruct.equals("help")) {
                    help();
                }
                order = instruct.split(" ");
                execute_order(order, now);
                System.out.print("请问你要做什么: ");
            }
        }
    }
    public static void help(){
        System.out.println("---------------帮助---------------");
        System.out.println("游戏的操作采用指令形式：指令1+空格+指令2");
        System.out.println("指令1的种类有：go, talk, take, use.");
        System.out.println("指令2的种类有：");
        System.out.println("go搭配方向: north, south, east, west; 表示出哪个门");
        System.out.println("talk搭配人物: ");
        System.out.println("take表示拿，use表示使用，搭配: ");
        System.out.println("----------------------------------");
    }
    public static void execute_order(String[] order, Building now){

    }
}